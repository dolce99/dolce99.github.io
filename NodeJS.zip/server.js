var http = require('http');
var curl = require('curl');
var qs = require('querystring');
var url = require('url');
var fs = require('fs');

var api = [];
api['like'] = 'https://graph.facebook.com/{id}/reactions?type=LIKE&access_token={access_token}&method=post';
api['love'] = 'https://graph.facebook.com/{id}/reactions?type=LOVE&access_token={access_token}&method=post';
api['wow'] = 'https://graph.facebook.com/{id}/reactions?type=WOW&access_token={access_token}&method=post';
api['haha'] = 'https://graph.facebook.com/{id}/reactions?type=HAHA&access_token={access_token}&method=post';
api['angry'] = 'https://graph.facebook.com/{id}/reactions?type=ANGRY&access_token={access_token}&method=post';
api['follow'] = 'https://graph.facebook.com/{id}/likes?access_token={access_token}&method=post';
api['addfriend'] = 'https://graph.facebook.com/{id}/likes?access_token={access_token}&method=post';

http.createServer(function (req, res) {
    if (req.method == 'POST') {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('success!');
        var body = '';
        req.on('data', function (data) {
            body += data;
            if (body.length > 1e6) {
                req.connection.destroy();
            }
        });
        req.on('end', function () {
            var POST = qs.parse(body);
            reactions(POST);
        });
    } else {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('Ahihi! Server Cron by TOMDZ');
    }
}).listen(8080);

function reactions(query) {
    var type = (query.type) ? query.type : 'like';
    var delay = (query.delay) ? query.delay : 100;
    if (query.id) {
        switch (query.type) {
            case 'like':
            case 'love':
            case 'wow':
            case 'haha':
            case 'angry':
            case 'follow':
            case 'addfriend':
                process(type, query.id, query, delay, 0);
                break;
            default:
        }
    }
}

function process(type, id, tokens, delay, i) {
    var interval = setInterval(function () {
        if (i >= Object.keys(tokens).length - 4) {
            console.log('finish!');
            clearInterval(interval);
            return 'finish!';
        }
        var apiUrl = parseUrl(parseUrl(api[type], '{id}', id), '{access_token}', tokens['tokens[' + i + ']']);
        curl.get(apiUrl, function (err, res, body) {
            console.log(apiUrl);
        });
        i++;
    }, delay);
}

function parseUrl(url, searchvalue, newvalue) {
    return url.replace(searchvalue, newvalue);
}
